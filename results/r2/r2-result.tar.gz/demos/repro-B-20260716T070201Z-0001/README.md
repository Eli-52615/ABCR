# 复现包 · B-20260716T070201Z-0001

## 诚实条款
> 本项目承诺的复现 = ① 工件级（原始输出永久保存，任何再分析不依赖重新生成）+ ② 统计级（同 config 重跑，聚合指标在自身抽样波动内一致）+ ③ 单机确定级（同机同环境 temp 0 双跑一致）。**不承诺跨硬件 bit 级一致**——浮点归约序差异是行业已知事实，声称 bit 级可复现反而不诚实。本包一切数字为 exploratory / rig-validation 性质，mini 环产出不构成任何假设的证据。
> ⚠ 本包含 `non_citable: true` 的 run（Mac dev 档）——一切呈现均按 non-citable 处理。

## 复评（独立复算，无需原仓库/权重）
```bash
python tools/rescore_standalone.py --pack . --report rescore_report.json
```
从 `runs/*/steps.jsonl` 的 output_text 以 A 的 rescore_copy 判分函数重算全部确定性指标，并与 scores.jsonl 的 deterministic_v1（B）/ rescore_v1（A）两组分数分别对比；预期两组一致率均 == 1.0。judge 指标（trait_score 等）非确定性，不在复算范围。

## 复跑（需原仓库与模型权重——包内不含权重）
复跑指向原仓库 B 的 dispatch，config 原件见 `configs/`：
```bash
# 在原仓库根（需 .venv312 + 模型权重）：
PYTHONPATH=src python -m abcr.ops.dispatch --envelope configs/<batch_id>.json ...
```
本包只保证工件级/统计级/单机确定级复现；复跑生成需要原仓库环境与权重，故与复评分列。

## 内容
- runs: 3 个（`runs/<run_id>/{manifest.json,steps.jsonl,scores.jsonl}`）
- configs/：信封原件 + 逐 run config
- activations/：10% 抽样激活摘要 npz（如有）
- figures/main.png：双联图（rig-validation, not evidence）
- tools/：rescore_copy.py（A 主副本）+ scorer_copy.py（B 双实现对照）+ rescore_standalone.py
- pack_manifest.json：逐文件 sha256 + bytes
- ACCEPTANCE.md：闭合验收协议（全新会话仅凭本包复算的完整指令书）

