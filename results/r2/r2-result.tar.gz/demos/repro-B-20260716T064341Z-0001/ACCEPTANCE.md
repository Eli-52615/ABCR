# 闭合验收协议 · B-20260716T064341Z-0001

> 本文件是给「**只拿到本目录的全新会话**」的完整指令书（R2 ④）。逐步执行，全程不回读原仓库。

## 1. 前提声明
你（验收会话）只拥有本目录。**禁止**访问原仓库、shared-brain、网络；一切依据 = 包内文件。
本包一切数字为 exploratory / rig-validation，non_citable，不构成任何科学结论。

## 2. 完整性核验（逐文件对 pack_manifest.json 核 sha256）
```bash
python -c "import json,hashlib,pathlib; m=json.load(open('pack_manifest.json')); bad=[f['path'] for f in m['files'] if hashlib.sha256(pathlib.Path(f['path']).read_bytes()).hexdigest()!=f['sha256']]; print('完整性:', 'PASS' if not bad else ('FAIL '+str(bad)))"
```
预期：PASS（本包共 21 个受清单管辖文件）。

## 3. 独立复算
```bash
python tools/rescore_standalone.py --pack . --report rescore_report.json
```
以 A 的 rescore_copy 重算全部确定性指标，对 deterministic_v1 与 rescore_v1 分别对比（AMENDMENT-20）。**预期两组一致率均 == 1.0**。任何不一致逐条列 (run_id, item_id, metric, scorer_id, 期望, 实得)。

## 4. 判定
一致率 100% **且** 完整性核验通过 = **PASS**；否则 **FAIL** 并原样报告（不许「大体一致」措辞）。

## 5. 报告格式
PASS/FAIL + 核验文件数 + 复算覆盖 (run,item,metric) 三元组数 + 不一致清单 + 验收会话环境（python 版本、平台）。

```bash
python -c "import json,platform,sys; r=json.load(open('rescore_report.json')); ok=r.get('integrity_ok') and r.get('agreement_deterministic_v1')==1.0 and r.get('agreement_rescore_v1')==1.0; print(('PASS' if ok else 'FAIL'), '| files', r.get('files_verified'), '| triples', r.get('recompute_triples'), '| det', r.get('agreement_deterministic_v1'), 'resc', r.get('agreement_rescore_v1'), '| env', sys.version.split()[0], platform.platform())"
```

批次 run 数：3。

