#!/usr/bin/env python3
"""复现包独立复评入口（stdlib + 同目录 rescore_copy/scorer_copy；不 import abcr 包）。

流程（AMENDMENT-20）：
  1. 按 pack_manifest.json 逐文件核 sha256——不符即报污染、退出码 2；
  2. 遍历 runs/*/steps.jsonl → 以 A 的 rescore_copy 判分函数为主重算全部确定性指标；
  3. 与 scores.jsonl 中 scorer_id ∈ {deterministic_v1(B), rescore_v1(A)} 两组分数
     逐 (run_id,item_id,step_id,seed,metric) 分别对比 → 各组一致率；
  4. judge 指标（trait_score 等）非确定性，不在复算范围。
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # 同目录两副本
import rescore_copy   # noqa: E402  A 主副本
import scorer_copy    # noqa: E402  B 第二副本（双实现对照，随包留证）

RECOMPUTE_SCORERS = ("deterministic_v1", "rescore_v1")


def _load_jsonl(p):
    return [json.loads(ln) for ln in Path(p).read_text(encoding="utf-8").splitlines() if ln.strip()]


def _verify_manifest(pack: Path):
    man = json.loads((pack / "pack_manifest.json").read_text(encoding="utf-8"))
    bad = []
    for f in man["files"]:
        fp = pack / f["path"]
        if not fp.exists():
            bad.append((f["path"], "缺失", f["sha256"], "-"))
            continue
        got = hashlib.sha256(fp.read_bytes()).hexdigest()
        if got != f["sha256"]:
            bad.append((f["path"], "sha256不符", f["sha256"], got))
    return man, bad


def _num_eq(a, b):
    try:
        return abs(float(a) - float(b)) <= 1e-9
    except (TypeError, ValueError):
        return a == b


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pack", required=True, help="复现包根目录")
    ap.add_argument("--report", required=True, help="复评报告输出 json")
    args = ap.parse_args()
    pack = Path(args.pack).resolve()

    man, bad = _verify_manifest(pack)
    if bad:
        rep = {"integrity_ok": False, "contamination": [
            {"path": p, "reason": r, "expected": e, "got": g} for p, r, e, g in bad]}
        Path(args.report).write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
        print("完整性核验失败（污染）：", len(bad), "个文件不符", file=sys.stderr)
        for p, r, e, g in bad:
            print(f"  {p}: {r}", file=sys.stderr)
        return 2

    # 重算：以 A 的 rescore_copy 为主副本
    recomputed = {}   # (run_id,item_id,step_id,seed,metric) -> value
    runs_root = pack / "runs"
    for steps_p in sorted(runs_root.glob("*/steps.jsonl")):
        for st in _load_jsonl(steps_p):
            for row in rescore_copy.rescore_step(st):
                key = (row["run_id"], row["item_id"], row["step_id"],
                       row["random_seed"], row["metric_name"])
                recomputed[key] = row["metric_value"]

    # 逐 scorer 组比对
    groups = {s: {"total": 0, "matched": 0, "mismatch": []} for s in RECOMPUTE_SCORERS}
    triples = set()
    for scores_p in sorted(runs_root.glob("*/scores.jsonl")):
        for r in _load_jsonl(scores_p):
            sid = r.get("scorer_id")
            if sid not in RECOMPUTE_SCORERS:
                continue
            key = (r.get("run_id"), r.get("item_id"), r.get("step_id"),
                   r.get("random_seed"), r.get("metric_name"))
            if key not in recomputed:
                continue   # 该指标不在 rescore_copy 复算范围（judge 等）
            g = groups[sid]
            g["total"] += 1
            triples.add((r.get("run_id"), r.get("item_id"), r.get("metric_name")))
            if _num_eq(recomputed[key], r.get("metric_value")):
                g["matched"] += 1
            else:
                g["mismatch"].append({
                    "run_id": key[0], "item_id": key[1], "step_id": key[2],
                    "seed": key[3], "metric": key[4], "scorer_id": sid,
                    "expected_recompute": recomputed[key], "got_scores": r.get("metric_value")})

    def agr(s):
        g = groups[s]
        return (g["matched"] / g["total"]) if g["total"] else 1.0

    rep = {
        "integrity_ok": True,
        "files_verified": len(man["files"]),
        "recompute_triples": len(triples),
        "agreement_deterministic_v1": agr("deterministic_v1"),
        "agreement_rescore_v1": agr("rescore_v1"),
        "compared": {s: groups[s]["total"] for s in RECOMPUTE_SCORERS},
        "mismatches": groups["deterministic_v1"]["mismatch"] + groups["rescore_v1"]["mismatch"],
    }
    Path(args.report).write_text(json.dumps(rep, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"integrity_ok=True files={rep['files_verified']} triples={rep['recompute_triples']}")
    print(f"agreement_deterministic_v1={rep['agreement_deterministic_v1']} "
          f"agreement_rescore_v1={rep['agreement_rescore_v1']}")
    if rep["mismatches"]:
        print(f"不一致 {len(rep['mismatches'])} 条：", file=sys.stderr)
        for m in rep["mismatches"]:
            print(f"  {m['run_id']} {m['item_id']} {m['metric']} ({m['scorer_id']}): "
                  f"期望{m['expected_recompute']} 实得{m['got_scores']}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
